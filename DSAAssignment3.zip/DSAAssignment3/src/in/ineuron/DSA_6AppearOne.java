package in.ineuron;
import java.io.*;

/*Given a non-empty array of integers nums, every element appears twice except
for one. Find that single one.

You must implement a solution with a linear runtime complexity and use only
constant extra space.*/
public class DSA_6AppearOne {
	

	static int findSingle(int A[], int ar_size)
	{

		// Iterate over every element
		for (int i = 0; i < ar_size; i++) {

		// Initialize count to 0
		int count = 0;

		for (int j = 0; j < ar_size; j++) {

			// Count the frequency
			// of the element
			if (A[i] == A[j]) {
			count++;
			}
		}

		// if the frequency of the
		// element is one
		if (count == 1) {
			return A[i];
		}
		}

		// if no element exist at most once
		return -1;
	}

	public static void main (String[] args) {
		int ar[] = { 2, 3, 5, 4, 5, 3, 4 };
		int n = ar.length;

		// Function call
		System.out.println("Element occurring once is " + findSingle(ar, n));
	}
}

